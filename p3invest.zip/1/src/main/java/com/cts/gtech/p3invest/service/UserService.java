package com.cts.gtech.p3invest.service;

import com.cts.gtech.p3invest.model.User;

public interface UserService {
	User registerUser(User user);

}
