package com.cts.gtech.p3invest.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.gtech.p3invest.model.Overview;

public interface OverviewRepository extends JpaRepository<Overview, String> {
	Boolean existsOverviewByPrname(String projectName);

}
