package com.cts.gtech.p3invest.service;

import java.util.Set;

import com.cts.gtech.p3invest.exceptions.CustomException;
import com.cts.gtech.p3invest.model.Login;

public interface LoginService {

	public Login add(Login login);
	public Login update(Login login);
	public Set<Login> getall();
	public Login get(String username,String password) throws CustomException;
	public void delete(String username);
}