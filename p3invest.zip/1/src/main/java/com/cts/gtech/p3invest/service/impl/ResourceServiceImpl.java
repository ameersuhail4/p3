package com.cts.gtech.p3invest.service.impl;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
 
import com.cts.gtech.p3invest.model.Resource;
import com.cts.gtech.p3invest.repo.ResourceRepository;
import com.cts.gtech.p3invest.service.ResourceService;
 
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
@Service
public class ResourceServiceImpl implements ResourceService {
    @Autowired
    private ResourceRepository employeeRepository;
    @Override
    public void save(MultipartFile file) {
        try {
            List<Resource> employees = parseExcelFile(file);
            for (Resource employee : employees) {
                if (employeeRepository.existsByEmpId(employee.getEmpId())) {
                    // If the employee already exists, update the existing record
                    Resource existingEmployee = employeeRepository.findByEmpId(employee.getEmpId());
                    if (existingEmployee != null) {
                        existingEmployee.setAssociateName(employee.getAssociateName());
                        existingEmployee.setDesignation(employee.getDesignation());
                        existingEmployee.setBillingStatus(employee.getBillingStatus());
                        existingEmployee.setOnboardingStatus(employee.getOnboardingStatus());
                        existingEmployee.setManager(employee.getManager());
                        employeeRepository.save(existingEmployee);
                    }
                } else {
                    // If the employee doesn't exist, add a new record
                    employeeRepository.save(employee);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public List<Resource> getAllEmployees() {
        return employeeRepository.findAll();
    }
    @Override
    public Resource getEmployeeById(String id) {
        return employeeRepository.findByEmpId(id); 
    }
    private List<Resource> parseExcelFile(MultipartFile file) throws IOException {
        List<Resource> employees = new ArrayList<>();
        Workbook workbook = new XSSFWorkbook(file.getInputStream());
        Sheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rows = sheet.iterator();
        while (rows.hasNext()) {
            Row currentRow = rows.next();
            if (currentRow.getRowNum() == 0) { // skip header
                continue;
            }
            Resource employee = new Resource();
            employee.setEmpId(getCellValue(currentRow.getCell(0))); // Ensure empId is of type String
            employee.setAssociateName(getCellValue(currentRow.getCell(1)));
            employee.setDesignation(getCellValue(currentRow.getCell(2)));
            employee.setBillingStatus(getCellValue(currentRow.getCell(3)));
            employee.setOnboardingStatus(getCellValue(currentRow.getCell(4)));
            employee.setManager(getCellValue(currentRow.getCell(5)));
            employees.add(employee);
        }
        workbook.close();
        return employees;
    }
    private String getCellValue(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    return String.valueOf((long) cell.getNumericCellValue());
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                switch (cell.getCachedFormulaResultType()) {
                    case NUMERIC:
                        return String.valueOf((long) cell.getNumericCellValue());
                    case STRING:
                        return cell.getStringCellValue();
                }
            default:
                return "";
        }
    }
}
