package com.cts.gtech.p3invest.service;

import org.springframework.web.multipart.MultipartFile;

import com.cts.gtech.p3invest.model.Tool;
 
import java.util.List;
 
public interface ToolService {
    void save(MultipartFile file);
    List<Tool> getTools();
    Tool getTools(String tool);
}