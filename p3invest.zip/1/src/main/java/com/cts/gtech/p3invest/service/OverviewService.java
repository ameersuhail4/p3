package com.cts.gtech.p3invest.service;

import java.util.List;
import java.util.Optional;

import com.cts.gtech.p3invest.exceptions.CustomException;
import com.cts.gtech.p3invest.model.Overview;

public interface OverviewService {
	
	List<Overview> getAllProjects();
	Optional<Overview> getProjectById(String projectName) throws CustomException;
	Overview saveProject(Overview project);
	void deleteProject(String projectName);
	void get(String projectName) throws CustomException;

}
