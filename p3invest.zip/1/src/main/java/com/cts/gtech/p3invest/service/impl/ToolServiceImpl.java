package com.cts.gtech.p3invest.service.impl;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
 
import com.cts.gtech.p3invest.model.Tool;
import com.cts.gtech.p3invest.repo.ToolRepository;
import com.cts.gtech.p3invest.service.ToolService;
 
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
@Service
public class ToolServiceImpl implements ToolService {
    @Autowired
    private ToolRepository toolRepository;
    @Override
    public void save(MultipartFile file) {
        try {
            List<Tool> tools = parseExcelFile(file);
            for (Tool tool : tools) {
                if (toolRepository.existsByTool(tool.getTool())) {
                    // If the tool already exists, update the existing record
                    Tool existingTool = null;
					try {
						existingTool = ToolRepository.findByTool(tool.getTool());
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                    if (existingTool != null) {
                    	existingTool.setTechnologyUsed(tool.getTechnologyUsed());
                    	existingTool.setBriefDescription(tool.getBriefDescription());
                    	existingTool.setTypeOfTool(tool.getTypeOfTool());
                    	existingTool.setDeveloper(tool.getDeveloper());
                    	existingTool.setProjectManager(tool.getProjectManager());
                    	existingTool.setPexLead(tool.getPexLead());
                    	existingTool.setCurrentStatus(tool.getCurrentStatus());
                        toolRepository.save(existingTool);
                    }
                } else {
                    // If the tool doesn't exist, add a new record
                    toolRepository.save(tool);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public List<Tool> getTools() {
        return toolRepository.findAll();
    }
    @Override
    public Tool getTools(String tool) {
        return ToolRepository.findByTool(tool); 
    }
    private List<Tool> parseExcelFile(MultipartFile file) throws IOException {
        List<Tool> tools = new ArrayList<>();
        Workbook workbook = new XSSFWorkbook(file.getInputStream());
        Sheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rows = sheet.iterator();
        while (rows.hasNext()) {
            Row currentRow = rows.next();
            if (currentRow.getRowNum() == 0) { // skip header
                continue;
            }
            Tool tool = new Tool();
            tool.setTool(getCellValue(currentRow.getCell(0))); // Ensure tool is of type String
            tool.setTechnologyUsed(getCellValue(currentRow.getCell(1)));
            tool.setBriefDescription(getCellValue(currentRow.getCell(2)));
            tool.setTypeOfTool(getCellValue(currentRow.getCell(3)));
            tool.setDeveloper(getCellValue(currentRow.getCell(4)));
            tool.setProjectManager(getCellValue(currentRow.getCell(5)));
            tool.setPexLead(getCellValue(currentRow.getCell(6)));
            tool.setCurrentStatus(getCellValue(currentRow.getCell(7)));
            tools.add(tool);
        }
        workbook.close();
        return tools;
    }
    private String getCellValue(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    return String.valueOf((long) cell.getNumericCellValue());
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                switch (cell.getCachedFormulaResultType()) {
                    case NUMERIC:
                        return String.valueOf((long) cell.getNumericCellValue());
                    case STRING:
                        return cell.getStringCellValue();
                }
            default:
                return "";
        }
    }
}

