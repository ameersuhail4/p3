package com.cts.gtech.p3invest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.gtech.p3invest.exceptions.CustomException;
import com.cts.gtech.p3invest.model.Login;
import com.cts.gtech.p3invest.service.LoginService;

@RestController
@RequestMapping("/login")
	@CrossOrigin("*")
	public class LoginController {

		@Autowired
		private LoginService lgnService;
		
		@PostMapping("/")
		public ResponseEntity<Login> addLoginUser(@RequestBody Login lgn){
			Login lgn1=this.lgnService.add(lgn);
			return ResponseEntity.ok(lgn1);
		}
		
		@PostMapping("/auth")
		public ResponseEntity<Login> getLoginUser(@RequestParam("username") String username,@RequestParam("password") String password) throws CustomException{
			
			
			return ResponseEntity.ok(this.lgnService.get(username,password));
		}
		
		@GetMapping("/")
		public ResponseEntity<?> getLoginUsers(){
			return ResponseEntity.ok(this.lgnService.getall());
		}
		
		@PutMapping("/")
		public ResponseEntity<Login> updateLoginUser(@RequestBody Login lgn) {
			return ResponseEntity.ok(this.lgnService.update(lgn));
		}
		
		@DeleteMapping("/{username}")
		public void deleteLoginUser(@PathVariable("username") String username) {
			this.lgnService.delete(username);
		}
	}



