package com.cts.gtech.p3invest.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.gtech.p3invest.exceptions.CustomException;
import com.cts.gtech.p3invest.model.Login;
import com.cts.gtech.p3invest.model.Overview;
import com.cts.gtech.p3invest.repo.OverviewRepository;
import com.cts.gtech.p3invest.service.OverviewService;

@Service
public class OverviewServiceImpl implements OverviewService {
 
    @Autowired    
    private OverviewRepository projectRepository;
    
    @Override
    public void get(String projectName) throws CustomException {
		
    	System.out.println("zzzz"+projectRepository.existsOverviewByPrname(projectName));
       if(!projectRepository.existsOverviewByPrname(projectName))
       {
    	 throw new CustomException("project details is not present for that purticular name");
       }
       
     
    }
 
    @Override
    public List<Overview> getAllProjects() {
        return projectRepository.findAll();
    }
 
    @Override
    public Optional<Overview> getProjectById(String projectName) throws CustomException {
    	if(!projectRepository.existsOverviewByPrname(projectName))
        {
     	 throw new CustomException("project details is not present for that purticular id");
        }
        return projectRepository.findById(projectName);
    }
 
    @Override
    public Overview saveProject(Overview project) {
        return projectRepository.save(project);
    }
 
    @Override
    public void deleteProject(String projectName) {
    	projectRepository.deleteById(projectName);
    }
}

