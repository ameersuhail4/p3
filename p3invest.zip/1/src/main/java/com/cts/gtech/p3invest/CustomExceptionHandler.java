package com.cts.gtech.p3invest;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cts.gtech.p3invest.exceptions.CustomException;

import org.springframework.http.HttpStatus;

@RestControllerAdvice
public class CustomExceptionHandler {
	 @ExceptionHandler({CustomException.class})
	    protected ResponseEntity<Object> handleIdNotExistException(CustomException e)
	    {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
	    }

}
