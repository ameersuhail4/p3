package com.cts.gtech.p3invest.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.gtech.p3invest.model.Login;

public interface LoginRepository extends JpaRepository<Login, String>{
	Boolean existsLoginByUsername(String userName);
    
    Login findByUsername(String userName);
    
   
}