package com.cts.gtech.p3invest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
 
import com.cts.gtech.p3invest.model.*;
import com.cts.gtech.p3invest.service.ToolService;
 
@RestController
@RequestMapping("/api/tools")
public class ToolController {
 
    @Autowired
    private ToolService toolService;
 
    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No file selected for uploading.");
        }
 
        try {
            toolService.save(file);
            return ResponseEntity.status(HttpStatus.OK).body("File uploaded successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload file: " + e.getMessage());
        }
    }
 
    @GetMapping
    public ResponseEntity<List<Tool>> getAllTools() {
        List<Tool> tools = toolService.getTools();
        return new ResponseEntity<>(tools, HttpStatus.OK);
    }
 
}
 