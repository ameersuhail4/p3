package com.cts.gtech.p3invest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.gtech.p3invest.exceptions.CustomException;
import com.cts.gtech.p3invest.model.User;
import com.cts.gtech.p3invest.service.UserService;

@RestController
@RequestMapping("/api/registration")
public class RegistrationController {
	
	@Autowired
	public UserService userService;
	
	@PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        try {
            validateUser(user);
            User registeredUser = userService.registerUser(user);
            return new ResponseEntity<>(registeredUser, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
 
    // Method to validate user input
    private void validateUser(User user) {
        if (user.getFirstname() == null || user.getFirstname().isEmpty()) {
            throw new IllegalArgumentException("Firstname is mandatory.");
        }
        if (!isValidName(user.getFirstname())) {
            throw new IllegalArgumentException("Firstname must contain only alphabetic characters.");
        }
        
        if (user.getLastname() == null || user.getLastname().isEmpty()) {
            throw new IllegalArgumentException("Lastname is mandatory.");
        }
        if (!isValidName(user.getLastname())) {
            throw new IllegalArgumentException("Lastname must contain only alphabetic characters.");
        }
        
        if (user.getUsername() == null || user.getUsername().isEmpty()) {
            throw new IllegalArgumentException("Username is mandatory.");
        }
        if (!isValidUsername(user.getUsername())) {
            throw new IllegalArgumentException("Username must contain '@' and end with '.com'.");
        }
        
        if (user.getPassword() == null || user.getPassword().isEmpty()) {
            throw new IllegalArgumentException("Password is mandatory.");
        }
        if (!isValidPassword(user.getPassword())) {
            throw new IllegalArgumentException("Password must contain at least one uppercase letter, one lowercase letter, one special character, and one number.");
        }
        
        if (user.getDesignation() == null || user.getDesignation().isEmpty()) {
            throw new IllegalArgumentException("Designation is mandatory.");
        }
        if (!isValidString(user.getDesignation())) {
            throw new IllegalArgumentException("Designation must contain only alphabetic characters.");
        }
        
        if (user.getRole() == null || user.getRole().isEmpty()) {
            throw new IllegalArgumentException("Role is mandatory.");
        }
        if (!isValidString(user.getRole())) {
            throw new IllegalArgumentException("Role must contain only alphabetic characters.");
        }
        if (user.getLdap() == null || user.getLdap().isEmpty()) {
            throw new IllegalArgumentException("ldap is mandatory.");
        }
        if (!isValidLdap(user.getLdap())) {
            throw new IllegalArgumentException("Username must contain '@' and end with '.com'.");
        }
    }
 
    // Helper methods for validation
    private boolean isValidName(String name) {
        return name.matches("^[a-zA-Z]+$");
    }
 
    private boolean isValidUsername(String username) {
        return username.matches("^[\\w.-]+@[a-zA-Z.-]+\\.com$");
    }
 
    private boolean isValidPassword(String password) {
        return password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");
    }
 
    private boolean isValidString(String value) {
        return value.matches("^[a-zA-Z]+$");
    }
    private boolean isValidLdap(String ldap) {
        return ldap.matches("^[\\w.-]+@[a-zA-Z.-]+\\.com$");
    }
}