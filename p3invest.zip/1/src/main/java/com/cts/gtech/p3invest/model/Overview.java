package com.cts.gtech.p3invest.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Getter 
@Setter
@Entity
public class Overview {
	
	@Id
	private String prname;
	private String prdetails;
	public Overview(String prname, String prdetails) {
		super();
		this.prname = prname;
		this.prdetails = prdetails;
	}
	
	public String getPrname() {
		return prname;
	}
	public void setPrname(String prname) {
		this.prname = prname;
	}
	public String getPrdetails() {
		return prdetails;
	}
	public void setPrdetails(String prdetails) {
		this.prdetails = prdetails;
	}
	public Overview() {
		super();
	}
    
}
