package com.cts.gtech.p3invest.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
 
import com.cts.gtech.p3invest.model.Tool;
@Repository
public interface ToolRepository extends JpaRepository<Tool, Long> {
	boolean existsByTool(String tool);//custom method to check tool
	static Tool findByTool(String tool) {		
		return null;
	} 
}