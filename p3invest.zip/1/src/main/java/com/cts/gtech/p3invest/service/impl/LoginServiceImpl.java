package com.cts.gtech.p3invest.service.impl;

import java.util.LinkedHashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.gtech.p3invest.exceptions.CustomException;
import com.cts.gtech.p3invest.model.Login;
import com.cts.gtech.p3invest.repo.LoginRepository;
import com.cts.gtech.p3invest.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	private LoginRepository logRepo;
	
	@Override
	public Login add(Login login) {
		return this.logRepo.save(login);
	}

	@Override
	public Login update(Login login) {
		return this.logRepo.save(login);
	}

//	@Override
//	public Set<Login> getall() {
//		return new LinkedHashSet<Login> (this.logRepo.findAll());
//	}
	@Override
    public Login get(String username,String password) throws CustomException {
		
       if(logRepo.existsLoginByUsername(username))
       {
    	   Login newlogin=logRepo.findByUsername(username);
    	   if(newlogin.getPassword().equals(password)) {
    		   throw new CustomException("Login Successfull");
    	   }
    	   else {
    		   throw new CustomException("Username or password incorrect");
    	   }
    	  
       }
       else
       {
           throw new CustomException("No user with userid:"+username);
       }
    }
	
	
	
	

//	@Override
//	public Login get(int userId,String password) throws CustomException {
//		Login newlogin=logRepo.findById(userId).get();
////		return this.logRepo.findById(userId).get();
//	}

	@Override
	public void delete(String userName) {
		this.logRepo.deleteById(userName);
	}

	@Override
	public Set<Login> getall() {
		// TODO Auto-generated method stub
		return null;
	}

}