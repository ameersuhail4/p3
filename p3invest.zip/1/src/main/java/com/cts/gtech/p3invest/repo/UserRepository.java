package com.cts.gtech.p3invest.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.gtech.p3invest.model.User;

public interface UserRepository extends JpaRepository<User,Long> {

}
