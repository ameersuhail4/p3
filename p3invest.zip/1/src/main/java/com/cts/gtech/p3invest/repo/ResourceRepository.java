package com.cts.gtech.p3invest.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
 
import com.cts.gtech.p3invest.model.Resource;
@Repository
public interface ResourceRepository extends JpaRepository<Resource, Long> {
	boolean existsByEmpId(String empId);//custom method to check existence
	Resource findByEmpId(String empId); //custom method to find by empId
}